package data;

public class Agentbookinginfo {
	
	String cusname,itemname,itemunit,agentname;
	int itemquantity,vesselid;
	float itemweight;
	
	public Agentbookinginfo() {
		
	}

	public String getCusname() {
		return cusname;
	}

	public void setCusname(String cusname) {
		this.cusname = cusname;
	}

	public String getItemname() {
		return itemname;
	}

	public void setItemname(String itemname) {
		this.itemname = itemname;
	}

	public String getItemunit() {
		return itemunit;
	}

	public void setItemunit(String itemunit) {
		this.itemunit = itemunit;
	}

	public int getItemquantity() {
		return itemquantity;
	}

	public void setItemquantity(int itemquantity) {
		this.itemquantity = itemquantity;
	}

	public int getVesselid() {
		return vesselid;
	}

	public void setVesselid(int vesselid) {
		this.vesselid = vesselid;
	}

	public float getItemweight() {
		return itemweight;
	}

	public void setItemweight(float itemweight) {
		this.itemweight = itemweight;
	}

	public String getAgentname() {
		return agentname;
	}

	public void setAgentname(String agentname) {
		this.agentname = agentname;
	}
	
	
	
}
