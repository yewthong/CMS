package data;

public class BookingSpace {

	int scheduleid;
	float totalspace;
	float avaialblespace;
	float occupied_space;
	
	public BookingSpace() {
		
	}

	public int getScheduleid() {
		return scheduleid;
	}

	public void setScheduleid(int scheduleid) {
		this.scheduleid = scheduleid;
	}

	public float getTotalspace() {
		return totalspace;
	}

	public void setTotalspace(float totalspace) {
		this.totalspace = totalspace;
	}

	public float getAvaialblespace() {
		return avaialblespace;
	}

	public void setAvaialblespace(float avaialblespace) {
		this.avaialblespace = avaialblespace;
	}

	public float getOccupied_space() {
		return occupied_space;
	}

	public void setOccupied_space(float occupied_space) {
		this.occupied_space = occupied_space;
	}

	
	
	
}
