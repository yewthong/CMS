package data;

public class LocationData {

	String location;
	
	public LocationData(){
		
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	
	
}
